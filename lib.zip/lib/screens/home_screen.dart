import 'package:flutter/material.dart';

import '../models/contato_model.dart';
import '../services/contato_banco.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  //============================================
  final _nomeController = TextEditingController();
  final _emailController = TextEditingController();
  final _telefoneController = TextEditingController();
  List<ContatoModel> _listarContatos = [];

  @override
  void initState() {
    super.initState();
    _carregarLista();
  }

  void _carregarLista() async {
    final contatos = await ContatoBanco().listarContatos();
    setState(() {
      _listarContatos = contatos;
    });
  }

  void abrirFormulario(ContatoModel contato) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Cadastro"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _nomeController,
                decoration: InputDecoration(label: Text("Nome")),
              ),
              SizedBox(height: 20),
              TextField(
                controller: _emailController,
                decoration: InputDecoration(label: Text("Email")),
              ),
              SizedBox(height: 20),
              TextField(
                controller: _telefoneController,
                decoration: InputDecoration(label: Text("Telefone")),
              ),
              SizedBox(height: 20),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancelar"),
            ),
            TextButton(
              onPressed: () => _salvarDados(contato),
              child: Text("Salvar"),
            ),
          ],
        );
      },
    );
  } //fim da função abrir formulario

  void _salvarDados(ContatoModel contato) async {
    // pega os dados do formulario e cria um novo contato
    final novoContato = ContatoModel(
      nome: _nomeController.text,
      email: _emailController.text,
      telefone: _telefoneController.text,
      id: contato.id,
    );
    //verifica se é modo de edição ou cadastro
    bool modoEdicao = contato.id == null; // se false, é modo de cadastro
    bool cadastrou = false;
    if (modoEdicao) {
      cadastrou = await ContatoBanco().inserirContato(novoContato);
    } else {
      cadastrou = await ContatoBanco().atualizarContato(novoContato);
    }
    if (cadastrou) {
      //atualiza a lista de contatos
      _carregarLista();
      //limpa os campos do formulario
      _nomeController.clear();
      _emailController.clear();
      _telefoneController.clear();
      //fecha o formulario
      Navigator.of(context).pop();
    }
  }

  // Modal de confirmação
  void _modalExclusao(ContatoModel contato) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Excluir contato"),
          content: Text("Tem certeza que deseja excluir ${contato.nome}?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancelar"),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _deletarContato(contato.id!);
              },
              child: Text("Excluir"),
            ),
          ],
        );
      },
    );
  }

  void _deletarContato(int id) async {
    bool deletou = await ContatoBanco().deletarContato(id);
    _carregarLista();
    if (deletou) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Contato deletado!")));
    }
  }

  //============================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Lista de contatos"),
        backgroundColor: Colors.deepPurple,
      ),
      body: ListView.builder(
        itemCount: _listarContatos.length, //conta numero de itens no array
        itemBuilder: (context, index) {
          final item = _listarContatos[index];
          return Card(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            child: ListTile(
              title: Text(item.nome),
              subtitle: Text('${item.email} - ${item.telefone}'),
              // onTap: () {}
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: () {
                      _modalExclusao(item);
                    },
                    icon: Icon(Icons.delete),
                  ),
                  IconButton(
                    onPressed: () {
                      // Lógica para editar o contato
                    },
                    icon: Icon(Icons.edit),
                  ),
                ],
              ),
              leading: CircleAvatar(child: Icon(Icons.person)),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          abrirFormulario(ContatoModel(nome: "", email: "", telefone: ""));
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
